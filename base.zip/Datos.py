import streamlit as st
st.image('images/banner.png')

st.title("Aanálisis de Datos en la Facultad de Informática")
st.subheader(" Con Python🐍")
st.write("¿Qué sabemos de (completar sobre los datos seleccionados)...")
